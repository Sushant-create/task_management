"""
Test suite for the Task Management System Flask app.

These tests mock the MySQL connection (via unittest.mock) so they run without a
live database — they check request/response/session behavior and the bug fixes
called out in the README, not the SQL itself.

Run with:
    pytest tests/test_samples.py -v
"""
import sys
import os
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import app as app_module  # noqa: E402


@pytest.fixture
def client():
    app_module.app.config["TESTING"] = True
    with app_module.app.test_client() as client:
        yield client


def make_mock_cursor(fetchone_result=None, fetchall_result=None):
    cursor = MagicMock()
    cursor.fetchone.return_value = fetchone_result
    cursor.fetchall.return_value = fetchall_result or []
    return cursor


def make_mock_conn(cursor):
    conn = MagicMock()
    conn.cursor.return_value = cursor
    conn.is_connected.return_value = True
    return conn


class TestLogin:
    def test_login_page_loads(self, client):
        response = client.get("/")
        assert response.status_code == 200

    def test_login_rejects_empty_fields(self, client):
        response = client.post("/", data={"username": "", "password": ""})
        assert response.status_code == 200
        assert b"Please enter both username and password" in response.data

    def test_login_success_with_hashed_password(self, client):
        from werkzeug.security import generate_password_hash

        hashed = generate_password_hash("admin123")
        cursor = make_mock_cursor(
            fetchone_result={"id": 1, "username": "admin", "password": hashed, "role": "admin"}
        )
        conn = make_mock_conn(cursor)

        with patch.object(app_module, "get_connection", return_value=conn):
            response = client.post(
                "/", data={"username": "admin", "password": "admin123"}, follow_redirects=False
            )
        assert response.status_code == 302
        assert "/tasks" in response.headers["Location"]

    def test_login_fails_with_wrong_password(self, client):
        from werkzeug.security import generate_password_hash

        hashed = generate_password_hash("admin123")
        cursor = make_mock_cursor(
            fetchone_result={"id": 1, "username": "admin", "password": hashed, "role": "admin"}
        )
        conn = make_mock_conn(cursor)

        with patch.object(app_module, "get_connection", return_value=conn):
            response = client.post("/", data={"username": "admin", "password": "wrongpass"})
        assert response.status_code == 200
        assert b"Invalid username, password, or role" in response.data

    def test_login_rejects_unknown_role(self, client):
        """A user row with a role outside admin/manager must not be able to log in,
        even with a correct password hash."""
        from werkzeug.security import generate_password_hash

        hashed = generate_password_hash("pw")
        cursor = make_mock_cursor(
            fetchone_result={"id": 5, "username": "guest", "password": hashed, "role": "guest"}
        )
        conn = make_mock_conn(cursor)

        with patch.object(app_module, "get_connection", return_value=conn):
            response = client.post("/", data={"username": "guest", "password": "pw"})
        assert b"Invalid username, password, or role" in response.data

    def test_login_db_error_shows_generic_message(self, client):
        """Regression test for the bug where raw DB exceptions were shown to the user."""
        with patch.object(app_module, "get_connection", side_effect=app_module.Error("boom")):
            response = client.post("/", data={"username": "admin", "password": "admin123"})
        assert response.status_code == 200
        assert b"boom" not in response.data
        assert b"try again" in response.data.lower()


class TestTaskManagement:
    def _login(self, client):
        with client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

    def test_tasks_redirects_when_not_logged_in(self, client):
        response = client.get("/tasks", follow_redirects=False)
        assert response.status_code == 302
        assert response.headers["Location"].endswith("/")

    def test_tasks_page_loads_when_logged_in(self, client):
        self._login(client)
        cursor = make_mock_cursor(fetchall_result=[])
        conn = make_mock_conn(cursor)
        with patch.object(app_module, "get_connection", return_value=conn):
            response = client.get("/tasks")
        assert response.status_code == 200

    def test_non_numeric_employee_id_does_not_crash(self, client):
        """Regression test: the original code called int(employee_id) unguarded,
        raising an uncaught ValueError (HTTP 500) for non-numeric input."""
        self._login(client)
        cursor = make_mock_cursor(fetchall_result=[])
        conn = make_mock_conn(cursor)
        with patch.object(app_module, "get_connection", return_value=conn):
            response = client.post(
                "/tasks",
                data={"employee_id": "not-a-number", "task_title": "Verify Documents", "completed": "false"},
            )
        assert response.status_code == 200
        assert b"All form fields are required and must be valid" in response.data

    def test_missing_fields_rejected(self, client):
        self._login(client)
        cursor = make_mock_cursor(fetchall_result=[])
        conn = make_mock_conn(cursor)
        with patch.object(app_module, "get_connection", return_value=conn):
            response = client.post("/tasks", data={"employee_id": "", "task_title": "", "completed": ""})
        assert response.status_code == 200
        assert b"All form fields are required and must be valid" in response.data

    def test_successful_task_insert_redirects(self, client):
        """Regression test for the Post/Redirect/Get fix: a successful insert should
        redirect rather than re-render the form (which would allow duplicate
        submissions on refresh)."""
        self._login(client)
        cursor = make_mock_cursor(fetchall_result=[])
        conn = make_mock_conn(cursor)
        with patch.object(app_module, "get_connection", return_value=conn):
            response = client.post(
                "/tasks",
                data={"employee_id": "1", "task_title": "Verify Documents", "completed": "false"},
                follow_redirects=False,
            )
        assert response.status_code == 302


class TestLogout:
    def test_logout_clears_session(self, client):
        with client.session_transaction() as sess:
            sess["user_id"] = 1
        response = client.get("/logout", follow_redirects=False)
        assert response.status_code == 302
        with client.session_transaction() as sess:
            assert "user_id" not in sess
