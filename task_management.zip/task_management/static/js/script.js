// Lightweight client-side validation. This is a UX convenience only —
// the server re-validates everything, since client-side checks can always
// be bypassed.

document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
        loginForm.addEventListener("submit", (event) => {
            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value.trim();
            if (!username || !password) {
                event.preventDefault();
                alert("Please enter both username and password.");
            }
        });
    }

    const taskForm = document.getElementById("task-form");
    if (taskForm) {
        taskForm.addEventListener("submit", (event) => {
            const employee = document.getElementById("employee_id").value;
            const title = document.getElementById("task_title").value;
            if (!employee || !title) {
                event.preventDefault();
                alert("Please select both an employee and a task title.");
            }
        });
    }
});
